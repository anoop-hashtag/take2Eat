<?php $__env->startSection('title', translate('Update Coupon')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="d-flex flex-wrap gap-2 align-items-center mb-4">
            <h2 class="h1 mb-0 d-flex align-items-center gap-2">
                <img width="20" class="avatar-img" src="<?php echo e(asset('public/assets/admin/img/icons/coupon.png')); ?>" alt="">
                <span class="page-header-title">
                    <?php echo e(translate('Coupon_Update')); ?>

                </span>
            </h2>
        </div>
        <!-- End Page Header -->


        <div class="row g-2">
            <div class="col-12">
                <form action="<?php echo e(route('admin.coupon.update',[$coupon['id']])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('title')); ?></label>
                                        <input type="text" name="title" value="<?php echo e($coupon['title']); ?>" class="form-control"
                                            placeholder="<?php echo e(translate('New coupon')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('coupon')); ?> <?php echo e(translate('type')); ?></label>
                                        <select name="coupon_type" class="form-control" onchange="coupon_type_change(this.value)">
                                            <option value="default" <?php echo e($coupon['coupon_type']=='default'?'selected':''); ?>>
                                                <?php echo e(translate('default')); ?>

                                            </option>
                                            <option value="first_order" <?php echo e($coupon['coupon_type']=='first_order'?'selected':''); ?>>
                                                <?php echo e(translate('first_Order')); ?>

                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6" id="limit-for-user" style="display: <?php echo e($coupon['coupon_type']=='first_order'?'none':'block'); ?>">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('limit_For_Same_User')); ?></label>
                                        <input type="number" name="limit" value="<?php echo e($coupon['limit']); ?>" class="form-control"
                                            placeholder="<?php echo e(translate('EX: 10')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('code')); ?></label>
                                        <input type="text" name="code" class="form-control" value="<?php echo e($coupon['code']); ?>"
                                            placeholder="<?php echo e(\Illuminate\Support\Str::random(8)); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label" for=""><?php echo e(translate('start_Date')); ?></label>
                                        <input type="text" name="start_date" class="js-flatpickr form-control flatpickr-custom" placeholder="<?php echo e(translate('Select dates')); ?>" value="<?php echo e(date('Y/m/d',strtotime($coupon['start_date']))); ?>"
                                            data-hs-flatpickr-options='{ "dateFormat": "Y/m/d", "minDate": "today" }'>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label" for=""><?php echo e(translate('expire_Date')); ?></label>
                                        <input type="text" name="expire_date" class="js-flatpickr form-control flatpickr-custom" placeholder="<?php echo e(translate('Select dates')); ?>" value="<?php echo e(date('Y/m/d',strtotime($coupon['expire_date']))); ?>"
                                            data-hs-flatpickr-options='{
                                            "dateFormat": "Y/m/d",
                                            "minDate": "today"
                                        }'>
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('min_Purchase')); ?></label>
                                        <input type="number" name="min_purchase" step="any" value="<?php echo e($coupon['min_purchase']); ?>"
                                            min="0" max="100000" class="form-control"
                                            placeholder="<?php echo e(translate('100')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6" id="max_discount_div" style="<?php if($coupon['discount_type']=='amount'): ?> display: none; <?php endif; ?>">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('max_Discount')); ?></label>
                                        <input type="number" min="0" max="1000000" step="any"
                                            value="<?php echo e($coupon['max_discount']); ?>" name="max_discount" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('discount_Type')); ?></label>
                                        <select name="discount_type" id="discount_type" class="form-control">
                                            <option value="percent" <?php echo e($coupon['discount_type']=='percent'?'selected':''); ?>><?php echo e(translate('percent')); ?></option>
                                            <option value="amount" <?php echo e($coupon['discount_type']=='amount'?'selected':''); ?>><?php echo e(translate('amount')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('discount_Amount')); ?></label>
                                        <input type="number" min="1" max="10000" step="any" value="<?php echo e($coupon['discount']); ?>"
                                            name="discount" class="form-control" placeholder="<?php echo e(translate('Ex: 500')); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end gap-3">
                                <button type="reset" class="btn btn-secondary" onclick=""><?php echo e(translate('reset')); ?></button>
                                <button type="submit" class="btn btn-primary"><?php echo e(translate('update')); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $("#discount_type").change(function(){
            if(this.value === 'amount') {
                $("#max_discount_div").hide();
            }
            else if(this.value === 'percent') {
                $("#max_discount_div").show();
            }
        });
    </script>
    <script>
        $(document).on('ready', function () {
            // INITIALIZATION OF FLATPICKR
            // =======================================================
            $('.js-flatpickr').each(function () {
                $.HSCore.components.HSFlatpickr.init($(this));
            });
        });

        function coupon_type_change(order_type) {
            if(order_type=='first_order'){
                $('#limit-for-user').hide();
            }else{
                $('#limit-for-user').show();
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/progocrm/food.progocrm.com/resources/views/admin-views/coupon/edit.blade.php ENDPATH**/ ?>