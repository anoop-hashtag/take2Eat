<!-- Header -->
<div class="card-header d-flex justify-content-between gap-10">
    <h5 class="mb-0"><?php echo e(translate('Top_Customer')); ?></h5>
    <a href="<?php echo e(route('admin.customer.list')); ?>" class="btn-link"><?php echo e(translate('View_All')); ?></a>
</div>
<!-- End Header -->

<!-- Body -->
<div class="card-body">
    <div class="d-flex flex-column gap-3">
        <?php $__currentLoopData = $top_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($item->customer)): ?>
                <a class="d-flex justify-content-between align-items-center text-dark" href='<?php echo e(route('admin.customer.view', [$item['user_id']])); ?>'>
                    <div class="media align-items-center gap-3">
                        <img class="rounded avatar avatar-lg"
                                onerror="this.src='<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>'"
                                src="<?php echo e(asset('storage/app/public/profile'.'/'. $item->customer->image  ?? '' )); ?>">
                        <div class="media-body d-flex flex-column" style="margin-right: 60px">
                            <span class="font-weight-semibold text-capitalize"><?php echo e($item->customer['f_name']??'Not exist'); ?></span>
                            <span class="text-dark"><?php echo e($item->customer['phone']?? translate('Not exist')); ?></span>
                        </div>
                    </div>
                    <span class="px-2 py-1 badge-soft-c1 font-weight-bold fz-12 rounded lh-1"><?php echo e(translate('Orders :')); ?><?php echo e($item['count']); ?></span>
                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- End Body -->
<?php /**PATH /home3/progocrm/food.progocrm.com/resources/views/admin-views/partials/_top-customer.blade.php ENDPATH**/ ?>