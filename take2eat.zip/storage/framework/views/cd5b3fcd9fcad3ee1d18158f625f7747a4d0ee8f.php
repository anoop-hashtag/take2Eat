<?php $__env->startSection('title', translate('Update delivery-man')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="d-flex flex-wrap gap-2 align-items-center mb-4">
            <h2 class="h1 mb-0 d-flex align-items-center gap-2">
                <img width="20" class="avatar-img" src="<?php echo e(asset('public/assets/admin/img/icons/deliveryman.png')); ?>" alt="">
                <span class="page-header-title">
                    <?php echo e(translate('update_Deliveryman')); ?>

                </span>
            </h2>
        </div>
        <!-- End Page Header -->

        <div class="row g-2">
            <div class="col-12">
                <form action="<?php echo e(route('admin.delivery-man.update',[$delivery_man['id']])); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0 d-flex align-items-center gap-2 mb-0">
                                <i class="tio-user"></i>
                                <?php echo e(translate('general_Information')); ?>

                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('first_Name')); ?></label>
                                        <input type="text" value="<?php echo e($delivery_man['f_name']); ?>" name="f_name"
                                               class="form-control" placeholder="New delivery-man"
                                               required>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('last_Name')); ?></label>
                                        <input type="text" value="<?php echo e($delivery_man['l_name']); ?>" name="l_name"
                                               class="form-control" placeholder="Last Name"
                                               required>
                                    </div>

                                </div>
                                <div class="col-md-6">

                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('identity_Type')); ?></label>
                                        <select name="identity_type" class="form-control">
                                            <option
                                                value="passport" <?php echo e($delivery_man['identity_type']=='passport'?'selected':''); ?>>
                                                <?php echo e(translate('passport')); ?>

                                            </option>
                                            <option
                                                value="driving_license" <?php echo e($delivery_man['identity_type']=='driving_license'?'selected':''); ?>>
                                                <?php echo e(translate('driving')); ?> <?php echo e(translate('license')); ?>

                                            </option>
                                            <option value="nid" <?php echo e($delivery_man['identity_type']=='nid'?'selected':''); ?>><?php echo e(translate('nid')); ?>

                                            </option>
                                            <option
                                                value="restaurant_id" <?php echo e($delivery_man['identity_type']=='restaurant_id'?'selected':''); ?>>
                                                <?php echo e(translate('restaurant_Id')); ?>

                                            </option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('identity_Number')); ?></label>
                                        <input type="text" name="identity_number" value="<?php echo e($delivery_man['identity_number']); ?>"
                                            class="form-control"
                                            placeholder="Ex : DH-23434-LS"
                                            required>
                                    </div>

                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('identity_Image')); ?></label>
                                        <div>
                                            <div class="row" id="coba"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">

                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('phone')); ?></label>
                                        <input type="text" name="phone" value="<?php echo e($delivery_man['phone']); ?>" class="form-control"
                                            placeholder="Ex : 017********"
                                            required>
                                    </div>

                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('branch')); ?></label>
                                        <select name="branch_id" class="form-control">
                                            <option value="0" <?php echo e($delivery_man['branch_id']==0?'selected':''); ?>><?php echo e(translate('all')); ?></option>
                                            <?php $__currentLoopData = \App\Model\Branch::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($branch['id']); ?>" <?php echo e($delivery_man['branch_id']==$branch['id']?'selected':''); ?>><?php echo e($branch['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label><?php echo e(translate('deliveryman_Image')); ?></label>
                                        <small class="text-danger">* ( <?php echo e(translate('ratio')); ?> 1:1 )</small>
                                        <div class="custom-file">
                                            <input type="file" name="image" id="customFileEg1" class="custom-file-input"
                                                accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                            <label class="custom-file-label" for="customFileEg1"><?php echo e(translate('choose_File')); ?></label>
                                        </div>
                                        <center class="mt-3">
                                            <img class="upload-img-view" id="viewer"
                                                onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                                src="<?php echo e(asset('storage/app/public/delivery-man').'/'.$delivery_man['image']); ?>" alt="delivery-man image"/>
                                        </center>
                                    </div>

                                    <?php $__currentLoopData = json_decode($delivery_man['identity_image'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- <div class="form-group">
                                        <img height="150"
                                            onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'"
                                            src="<?php echo e(asset('storage/app/public/delivery-man').'/'.$img); ?>">
                                    </div> -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-3">
                        <div class="card-header">
                            <h5 class="mb-0 d-flex align-items-center gap-2 mb-0">
                                <i class="tio-user"></i>
                                <?php echo e(translate('Account_Information')); ?>

                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('email')); ?></label>
                                        <input type="email" value="<?php echo e($delivery_man['email']); ?>" name="email" class="form-control"
                                            placeholder="Ex : ex@example.com"
                                            required>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="form-group">
                                        <label class="input-label"><?php echo e(translate('password')); ?></label>
                                        <div class="input-group input-group-merge">
                                            <input type="password" name="password" class="js-toggle-password form-control form-control input-field" id="password"
                                                   placeholder="<?php echo e(translate('Ex: 8+ Characters')); ?>"
                                                   data-hs-toggle-password-options='{
                                                "target": "#changePassTarget",
                                                "defaultClass": "tio-hidden-outlined",
                                                "showClass": "tio-visible-outlined",
                                                "classChangeTarget": "#changePassIcon"
                                                }'>
                                            <div id="changePassTarget" class="input-group-append">
                                                <a class="input-group-text" href="javascript:">
                                                    <i id="changePassIcon" class="tio-visible-outlined"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="form-group">
                                        <label for="confirm_password"><?php echo e(translate('confirm_Password')); ?></label>
                                        <div class="input-group input-group-merge">
                                            <input type="password" name="confirm_password" class="js-toggle-password form-control form-control input-field"
                                                   id="confirm_password" placeholder="<?php echo e(translate('confirm password')); ?>"
                                                   data-hs-toggle-password-options='{
                                                "target": "#changeConPassTarget",
                                                "defaultClass": "tio-hidden-outlined",
                                                "showClass": "tio-visible-outlined",
                                                "classChangeTarget": "#changeConPassIcon"
                                                }'>
                                            <div id="changeConPassTarget" class="input-group-append">
                                                <a class="input-group-text" href="javascript:">
                                                    <i id="changeConPassIcon" class="tio-visible-outlined"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mt-3 gap-3">
                        <button type="reset" class="btn btn-secondary"><?php echo e(translate('reset')); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(translate('submit')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>

    <script src="<?php echo e(asset('public/assets/admin/js/spartan-multi-image-picker.js')); ?>"></script>
    <script type="text/javascript">
        $(function () {
            $("#coba").spartanMultiImagePicker({
                fieldName: 'identity_image[]',
                maxCount: 5,
                rowHeight: '230px',
                groupClassName: 'col-6 col-lg-4 ',
                maxFileSize: '',
                placeholderImage: {
                    image: '<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>',
                    width: '100%'
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('Please only input png or jpg type file', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('File size too big', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/progocrm/food.progocrm.com/resources/views/admin-views/delivery-man/edit.blade.php ENDPATH**/ ?>