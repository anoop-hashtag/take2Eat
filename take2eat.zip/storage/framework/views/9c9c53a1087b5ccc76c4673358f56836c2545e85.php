
<?php if($tables != null): ?>
<?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="dropright">
        <div class="card table_hover-btn py-4 <?php echo e($table['order'] != null ? 'bg-c1' : 'bg-gray'); ?> stopPropagation"

        >
            <div class="card-body mx-3 position-relative text-center">


                <h3 class="card-title mb-2"><?php echo e(translate('table')); ?></h3>
                <h5 class="card-title mb-1"><?php echo e($table['number']); ?></h5>
                <h5 class="card-title mb-1"><?php echo e(translate('capacity')); ?>: <?php echo e($table['capacity']); ?></h5>
            </div>
        </div>
        <div class="table_hover-menu px-3">
            <h3 class="mb-3"><?php echo e(translate('Table - D2 ')); ?></h3>
            <?php if(($table['order'] != null)): ?>
                <?php $__currentLoopData = $table['order']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="fz-14 mb-1"><?php echo e(translate('order id')); ?>: <strong><?php echo e($order['id']); ?></strong></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="fz-14 mb-1"><?php echo e(translate('current status')); ?> - <strong><?php echo e(translate('empty')); ?></strong></div>
                <div class="fz-14 mb-1"><?php echo e(translate('any reservation')); ?> - <strong><?php echo e(translate('N/A')); ?></strong></div>
            <?php endif; ?>





        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="col-md-12 text-center">
        <h4 class=""><?php echo e(translate('This branch has no table')); ?></h4>
    </div>
<?php endif; ?>


<!-- tAble Info Modal -->
<div class="modal fade" id="tableInfoModal" tabindex="-1" role="dialog" aria-labelledby="tableInfoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="text-center position-relative px-4 py-5">
            <button type="button" class="close text-primary position-absolute right-2 top-2 fz-24" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>

            <h3 class="mb-3"><?php echo e(translate('Table# - D2 ')); ?></h3>
            <div class="fz-14 mb-1"><?php echo e(translate('current status')); ?> - <strong><?php echo e(translate('Available')); ?></strong></div>
            <div class="fz-14 mb-1"><?php echo e(translate('any reservation')); ?> - <strong><?php echo e(translate('5 Reservation')); ?></strong></div>

            <div class="d-flex flex-wrap justify-content-center text-nowrap gap-2 mt-4">
                <div class="bg-gray rounded d-flex flex-column gap-2 p-3">
                    <h6 class="mb-0">Today</h6>
                    <p class="mb-0">12:00 - 23:00</p>
                </div>
                <div class="bg-gray rounded d-flex flex-column gap-2 p-3">
                    <h6 class="mb-0">Tomorrow</h6>
                    <p class="mb-0">12:00 - 23:00</p>
                    <p class="mb-0">12:00 - 23:00</p>
                </div>
                <div class="bg-gray rounded d-flex flex-column gap-2 p-3">
                    <h6 class="mb-0">Today</h6>
                    <p class="mb-0">12:00 - 23:00</p>
                </div>
            </div>

            <div class="d-flex mt-5 mx-lg-5">
                <a href="#" class="btn btn-outline-primary w-100 text-nowrap" data-dismiss="modal" data-toggle="modal" data-target="#reservationModal"><i class="tio-alarm-alert"></i> <?php echo e(translate('Create_Reservation')); ?></a>
            </div>
        </div>
    </div>
  </div>
</div>

<!-- Reservatrion Modal -->
<div class="modal fade" id="reservationModal" tabindex="-1" role="dialog" aria-labelledby="reservationModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="position-relative px-4 py-5">
            <button type="button" class="close text-primary position-absolute right-2 top-2 fz-24" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <form action="#">
                <div class="text-center">
                    <h3 class="mb-3"><?php echo e(translate('Table# - D2 ')); ?></h3>
                    <div class="fz-14 mb-1"><?php echo e(translate('current status')); ?> - <strong><?php echo e(translate('Available')); ?></strong></div>
                </div>

                <div class="mb-4 mt-5">
                    <label for="table_no"><?php echo e(translate('Table_No')); ?></label>
                    <select name="table_no" id="table_no" class="custom-select">
                        <option value="#" selected disabled><?php echo e(translate('Select_Tables')); ?></option>
                        <option value="#"><?php echo e(translate('D1')); ?></option>
                        <option value="#"><?php echo e(translate('D2')); ?></option>
                        <option value="#"><?php echo e(translate('D3')); ?></option>
                        <option value="#"><?php echo e(translate('D4')); ?></option>
                        <option value="#"><?php echo e(translate('D5')); ?></option>
                        <option value="#"><?php echo e(translate('D6')); ?></option>
                        <option value="#"><?php echo e(translate('D7')); ?></option>
                    </select>
                </div>

                <div class="mb-4 mt-5">
                    <label for="reservation_time"><?php echo e(translate('Reservation_Time')); ?></label>
                    <input type="date" id="reservation_time" class="form-control">
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-4">
                            <label for="start_time"><?php echo e(translate('Start_Time')); ?></label>
                            <input type="time" id="start_time" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-4">
                            <label for="end_time"><?php echo e(translate('end_Time')); ?></label>
                            <input type="time" id="end_time" class="form-control">
                        </div>
                    </div>
                </div>

                <p class="text-primary text-center mt-3"> *  Sorry, There is already another reservation in this time </p>

                <div class="d-flex justify-content-center mt-4">
                    <button type="submit" class="btn btn-primary px-lg-5 text-nowrap"><?php echo e(translate('Book_Reservation')); ?></button>
                </div>
            </form>
        </div>
    </div>
  </div>
</div>
<?php /**PATH /home3/progocrm/food.progocrm.com/resources/views/admin-views/table/table_available_card2.blade.php ENDPATH**/ ?>