<?php $__env->startSection('title', translate('Edit Role')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="d-flex flex-wrap gap-2 align-items-center mb-4">
            <h2 class="h1 mb-0 d-flex align-items-center gap-2">
                <img width="20" class="avatar-img" src="<?php echo e(asset('public/assets/admin/img/icons/product.png')); ?>" alt="">
                <span class="page-header-title">
                    <?php echo e(translate('update_employee_role')); ?>

                </span>
            </h2>
        </div>
        <!-- End Page Header -->

        <!-- Content Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <form id="submit-create-role" action="<?php echo e(route('admin.custom-role.update',[$role['id']])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name"><?php echo e(translate('role_name')); ?></label>
                                <input type="text" name="name" value="<?php echo e($role['name']); ?>" class="form-control" id="name"
                                       aria-describedby="emailHelp"
                                       placeholder="<?php echo e(translate('Ex')); ?> : <?php echo e(translate('Store')); ?>">
                            </div>


                            <div class="mb-5 d-flex flex-wrap align-items-center gap-3">
                                <h5 class="mb-0"><?php echo e(translate('Module_Permission')); ?> : </h5>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="select-all-btn">
                                    <label class="form-check-label" for="select-all-btn"><?php echo e(translate('Select_All')); ?></label>
                                </div>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = MANAGEMENT_SECTION; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xl-4 col-lg-4 col-sm-6">
                                        <div class="form-group form-check">
                                            <input type="checkbox" name="modules[]" value="<?php echo e($section); ?>" class="form-check-input select-all-associate"
                                                   <?php echo e(in_array($section,(array)json_decode($role['module_access']))?'checked':''); ?>

                                                   id="<?php echo e($section); ?>">
                                            <label class="form-check-label ml-3" for="<?php echo e($section); ?>"><?php echo e(translate($section)); ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="d-flex justify-content-end gap-3">
                                <button type="reset" class="btn btn-secondary"><?php echo e(translate('reset')); ?></button>
                                <button type="submit" class="btn btn-primary"><?php echo e(translate('update')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>

    $('#submit-create-role').on('submit',function(e){

        var fields = $("input[name='modules[]']").serializeArray();
        if (fields.length === 0)
        {
            toastr.warning('<?php echo e(translate('select_minimum_one_selection_box')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
            return false;
        }else{
            $('#submit-create-role').submit();
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script_2'); ?>

    <script>
        $(document).ready(function() {
            // Check or uncheck "Select All" based on other checkboxes
            $(".select-all-associate").on('change', function (){
                if ($(".select-all-associate:checked").length == $(".select-all-associate").length) {
                    $("#select-all-btn").prop("checked", true);
                } else {
                    $("#select-all-btn").prop("checked", false);
                }
            });

            // Check or uncheck all checkboxes based on "Select All" checkbox
            $("#select-all-btn").on('change', function (){
                if ($("#select-all-btn").is(":checked")) {
                    $(".select-all-associate").prop("checked", true);
                } else {
                    $(".select-all-associate").prop("checked", false);
                }
            });

            // Check "Select All" checkbox on page load if all checkboxes are checked
            if ($(".select-all-associate:checked").length == $(".select-all-associate").length) {
                $("#select-all-btn").prop("checked", true);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/progocrm/food.progocrm.com/resources/views/admin-views/custom-role/edit.blade.php ENDPATH**/ ?>