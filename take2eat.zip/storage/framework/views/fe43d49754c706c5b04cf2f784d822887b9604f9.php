<?php $__env->startSection('title', translate('Settings')); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="d-flex flex-wrap gap-2 align-items-center mb-4">
            <h2 class="h1 mb-0 d-flex align-items-center gap-2">
                <img width="20" class="avatar-img" src="<?php echo e(asset('public/assets/admin/img/icons/business_setup2.png')); ?>" alt="">
                <span class="page-header-title">
                    <?php echo e(translate('business_setup')); ?>

                </span>
            </h2>
        </div>
        <!-- End Page Header -->

        <!-- Inine Page Menu -->
        <?php echo $__env->make('admin-views.business-settings.partials._business-setup-inline-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="row g-2">

            <!-- Business Information -->
            <div class="col-12">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <form action="<?php echo e(route('admin.business-settings.restaurant.cookies-setup-update')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php ($cookies=\App\CentralLogics\Helpers::get_business_settings('cookies')); ?>

                                    <div class="d-flex flex-wrap justify-content-between">
                                        <span class="text-dark"><?php echo e(translate('Cookie Text')); ?></span>
                                        <label class="switch--custom-label toggle-switch toggle-switch-sm d-inline-flex">
                                            <input type="checkbox" name="status" value="1" class="toggle-switch-input" <?php echo e($cookies?($cookies['status']==1?'checked':''):''); ?>>
                                            <span class="toggle-switch-label text">
                                            <span class="toggle-switch-indicator"></span>
                                        </span>
                                        </label>
                                    </div>
                                    <div class="form-group pt-3">
                                        <textarea name="text" class="form-control" rows="6" placeholder="<?php echo e(translate('Cookies text')); ?>" required><?php echo e($cookies['text']); ?></textarea>
                                    </div>
                                    <div class="btn--container justify-content-end">
                                        <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>" onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>"
                                                class="btn btn-primary"><?php echo e(translate('save')); ?></button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/progocrm/food.progocrm.com/resources/views/admin-views/business-settings/cookies-setup-index.blade.php ENDPATH**/ ?>