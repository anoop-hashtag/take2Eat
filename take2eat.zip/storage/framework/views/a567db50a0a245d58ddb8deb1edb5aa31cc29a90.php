<div class="modal fade" id="activatedThemeModal" tabindex="-1" role="dialog" aria-labelledby="activatedThemeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="activateData">

        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\foodapp\resources\views/admin-views/system/addon/partials/activation-modal.blade.php ENDPATH**/ ?>