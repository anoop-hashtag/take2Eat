<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr class="status-<?php echo e($order['order_status']); ?> class-all">
        <td class="">
            <?php echo e($key+1); ?>

        </td>
        <td class="table-column-pl-0">
            <a href="<?php echo e(route('admin.orders.details',['id'=>$order['id']])); ?>"><?php echo e($order['id']); ?></a>
        </td>
        <td><?php echo e(date('d M Y',strtotime($order['created_at']))); ?></td>
        <td>
            <?php if($order->customer): ?>
                <a class="text-body text-capitalize"
                   href="<?php echo e(route('admin.customer.view',[$order['user_id']])); ?>"><?php echo e($order->customer['f_name'].' '.$order->customer['l_name']); ?></a>
            <?php else: ?>
                <label class="badge badge-danger"><?php echo e(translate('invalid')); ?> <?php echo e(translate('customer')); ?> <?php echo e(translate('data')); ?></label>
            <?php endif; ?>
        </td>
        <td>
            <label class="badge badge-soft-primary"><?php echo e($order->branch?$order->branch->name:'Branch deleted!'); ?></label>
        </td>
        <td><?php echo e(\App\CentralLogics\Helpers::set_symbol($order['order_amount'])); ?></td>
        <td class="text-capitalize">
            <?php if($order['order_status']=='pending'): ?>
                <span class="badge badge-soft-info ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-info"></span><?php echo e(translate('pending')); ?>

                                    </span>
            <?php elseif($order['order_status']=='confirmed'): ?>
                <span class="badge badge-soft-info ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-info"></span><?php echo e(translate('confirmed')); ?>

                                    </span>
            <?php elseif($order['order_status']=='processing'): ?>
                <span class="badge badge-soft-warning ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-warning"></span><?php echo e(translate('processing')); ?>

                                    </span>
            <?php elseif($order['order_status']=='out_for_delivery'): ?>
                <span class="badge badge-soft-warning ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-warning"></span><?php echo e(translate('out_for_delivery')); ?>

                                    </span>
            <?php elseif($order['order_status']=='delivered'): ?>
                <span class="badge badge-soft-success ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-success"></span><?php echo e(translate('delivered')); ?>

                                    </span>
            <?php else: ?>
                <span class="badge badge-soft-danger ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-danger"></span><?php echo e(str_replace('_',' ',$order['order_status'])); ?>

                                    </span>
            <?php endif; ?>
        </td>
        <td>
            <div class="dropdown">
                <button class="btn btn-outline-secondary dropdown-toggle" type="button"
                        id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                    <i class="tio-settings"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item"
                       href="<?php echo e(route('admin.orders.details',['id'=>$order['id']])); ?>"><i
                            class="tio-visible"></i> <?php echo e(translate('view')); ?></a>
                    <a class="dropdown-item" target="_blank"
                       href="<?php echo e(route('admin.orders.generate-invoice',[$order['id']])); ?>"><i
                            class="tio-download"></i> <?php echo e(translate('invoice')); ?></a>
                </div>
            </div>
        </td>
    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH /home3/progocrm/food.progocrm.com/resources/views/admin-views/order/partials/_table.blade.php ENDPATH**/ ?>