

<input type="hidden" value="<?php echo e($template); ?>" name="email_template">
<?php /**PATH /home4/hashtagl/breadz.getanapp.co.in/resources/views/admin-views/business-settings/email-format-setting/partials/email-template-section.blade.php ENDPATH**/ ?>